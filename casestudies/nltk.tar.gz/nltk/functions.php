<?php

function import_deps(){
    $__pyhyp__import_deps = embed_py_func("def __pyhyp__import_deps():\n    import sys\n    sys.exec_prefix = sys.prefix = \"/home/lukas/research/pypyenv\"\n    sys.path.append(\"/home/lukas/research/hippy/pypy-hippy-bridge/lib_pypy/\")\n    sys.path.append(\"/home/lukas/research/hippy/pypy-hippy-bridge/lib-python/2.7\")\n    sys.path.append(\"/home/lukas/research/pypyenv/site-packages\")\n    import nltk");
    return $__pyhyp__import_deps();
}

function nltk_addformbutton_do(){
    echo "<input type=\"submit\" name=\"nltk\" value=\"Check people\">";
}

function nltk_showresults_do(){
    if(isset($_GET["nltk"])){
        import_deps();
        $body = $_GET["body"];
        $nltk = import_py_mod("nltk");
        $tokens = $nltk->word_tokenize($body);
        $tags = $nltk->pos_tag($tokens);
        $possible_names = array();
        foreach($tags as $tag){
            if ($tag->__getitem__(1) == "NNP"){
                $name = $tokens[$tag->__getitem__(0)];
                $possible_names[] = $name;
            }
        }
        $emails = strtolower($_GET["send_to"] . $_GET["send_to_cc"] . $_GET["send_to_bcc"] . $_GET["username"]);
        $missing_names = array();

        echo "<div style=\"background-color: #ff6600; box-shadow: 0px 0px 3px #333; padding:10px; width: 60%; margin: auto;\">";
        echo "<strong>Included people</strong>";
        echo "<ul>";

        foreach($possible_names as $name){
            if (strpos($emails, strtolower($name)) !== false){
                echo "<li> $name";
            }
            else{
                $missing_names[] = $name;
            }
        }
        echo "</ul>";
        echo "<strong>Forgotten people</strong>";
        echo "<ul>";

        foreach($missing_names as $name){
            echo "<li> $name";
        }
        echo "</ul>";
        echo "</div>";
    }
}
?>
