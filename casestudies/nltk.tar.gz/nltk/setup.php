<?php

/**
  * SquirrelMail Test Plugin
  * @copyright 2006-2011 The SquirrelMail Project Team
  * @license http://opensource.org/licenses/gpl-license.php GNU Public License
  * @version $Id$
  * @package plugins
  * @subpackage test
  */

/**
  * Register this plugin with SquirrelMail
  * 
  * @return void
  *
  */
function squirrelmail_plugin_init_nltk() {

    global $squirrelmail_plugin_hooks;

    $squirrelmail_plugin_hooks['compose_button_row']['nltk'] 
        = 'nltk_addformbutton';

    $squirrelmail_plugin_hooks['compose_bottom']['nltk'] 
        = 'nltk_showresults';
}


/**
  * Add link to menu at top of content pane
  *
  * @return void
  *
  */
function nltk_addformbutton() {

    include_once(SM_PATH . 'plugins/nltk/functions.php');
    return nltk_addformbutton_do();

}

function nltk_showresults() {

    include_once(SM_PATH . 'plugins/nltk/functions.php');
    return nltk_showresults_do();

}
