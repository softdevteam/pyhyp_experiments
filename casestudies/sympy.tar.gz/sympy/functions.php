<?php{
embed_py_func_global("def sympy_deps():\n    import sys\n    sys.exec_prefix = sys.prefix = \"/home/lukas/research/pypyenv\"\n    sys.path.append(\"/home/lukas/research/hippy/pypy-hippy-bridge/lib_pypy/\")\n    sys.path.append(\"/home/lukas/research/hippy/pypy-hippy-bridge/lib-python/2.7\")\n    sys.path.append(\"/home/lukas/research/hippy/pypy-hippy-bridge/lib-python/2.7/lib-tk\")\n    sys.path.append(\"/home/lukas/research/pypyenv/site-packages\")\n    sys.path.append(\"/home/lukas/research/pypyenv/site-packages/matplotlib-1.4.x-py2.7-linux-x86_64.egg\")\n    import os\n    try:\n        os.environ[\"PATH\"]\n    except KeyError:\n        os.environ[\"PATH\"] = \"/usr/bin/\"");

function sympy_addformbutton_do(){
    echo "<input type=\"submit\" name=\"sympypreview\" value=\"Preview SymPy\">";
}

function sympy_showpreview_do(){
    if(isset($_GET["sympypreview"])){
        sympy_deps();
        $body = $_GET["body"];
        $matches = array();
        preg_match_all("/```(.*?)```/s", $body, $matches);
        $a_codes = $matches[1];
        $i = 0;
        $sympy = import_py_mod("sympy");
        foreach($a_codes as $code){
            $i++;
            $a = $sympy->sympify($code);
            $name = SM_PATH . "_cache/formula_$i.png";
            call_user_func(embed_py_func("f = lambda: sympy.preview(a, output=\"png\", filename=\"%s\" % (name,), viewer=\"file\");"));
        }
        $newbody = preg_replace_callback("/```(.*?)```/s", "rep_count", $body);
        $newbody = str_replace("\n", "<br>", $newbody);
        echo "<center><h3>Preview</h3></center>";
        echo "<div style=\"box-shadow: 0px 0px 3px #333; margin: auto; padding: 10px; width: 60%;\">";
        echo $newbody;
        echo "</div>";
    }
}

$count = 1;
function rep_count($matches){
    global $count;
    return "<img src=\"" . SM_PATH . "_cache/formula_" . ++$count . ".png\" alt=\"formula\" />";
}

function sympy_changebody_do(&$body){
    $msg = $body[1];
    sympy_deps();
    $matches = array();
    preg_match_all("/```(.*?)```/s", $msg, $matches);
    $a_codes = $matches[1];
    formulas_to_images($a_codes);
    $newbody = preg_replace_callback("/```(.*?)```/s", "rep_count", $msg);
    $body[1] = $newbody;
    return $body;
}

embed_py_func_global("def formulas_to_images(formulas):\n    import sympy\n    i = 0\n    for f in formulas.as_list():\n        i += 1\n        tmp = sympy.sympify(f)\n        name = \"%s_cache/formula_%s.png\" % (SM_PATH, i)\n        sympy.preview(tmp, output=\"png\", filename = name, viewer = \"file\")\n");
}?>