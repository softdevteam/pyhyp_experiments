<?php

/**
  * SquirrelMail Test Plugin
  * @copyright 2006-2011 The SquirrelMail Project Team
  * @license http://opensource.org/licenses/gpl-license.php GNU Public License
  * @version $Id$
  * @package plugins
  * @subpackage test
  */

/**
  * Register this plugin with SquirrelMail
  * 
  * @return void
  *
  */
function squirrelmail_plugin_init_sympy() {

    global $squirrelmail_plugin_hooks;

    $squirrelmail_plugin_hooks['compose_button_row']['sympy'] 
        = 'sympy_addformbutton';

    $squirrelmail_plugin_hooks['compose_bottom']['sympy'] 
        = 'sympy_showpreview';

    $squirrelmail_plugin_hooks['message_body']['sympy'] 
        = 'sympy_changebody';

    $squirrelmail_plugin_hooks['attachment */*']['sympy'] 
        = 'sympy_attachment';
}


/**
  * Add link to menu at top of content pane
  *
  * @return void
  *
  */
function sympy_addformbutton() {

    include_once(SM_PATH . 'plugins/sympy/functions.php');
    return sympy_addformbutton_do();

}

function sympy_showpreview() {

    include_once(SM_PATH . 'plugins/sympy/functions.php');
    return sympy_showpreview_do();

}

function sympy_changebody(&$body) {

    include_once(SM_PATH . 'plugins/sympy/functions.php');
    return sympy_changebody_do($body);

}

function sympy_attachment($hookresult1, $startMessage, $id, $urlMailbox, $ent, $hookresult6, $display_filename, $where, $what){
}


